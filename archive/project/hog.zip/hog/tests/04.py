test = {
  'name': 'Question 4',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> more_boar(21, 43)
          bc6c4798917b91886d7fa5f56e42878f
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> more_boar(32, 33)
          d763fd836a7bfb096222e985b161b406
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> more_boar(6, 18)
          bc6c4798917b91886d7fa5f56e42878f
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> more_boar(22, 43)
          bc6c4798917b91886d7fa5f56e42878f
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> more_boar(23, 23)
          d763fd836a7bfb096222e985b161b406
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> more_boar(209, 980)
          bc6c4798917b91886d7fa5f56e42878f
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> a = more_boar(3, 92)
          >>> a # check that the value is being returned, not printed
          d763fd836a7bfb096222e985b161b406
          # locked
          """,
          'hidden': False,
          'locked': True
        },
        {
          'code': r"""
          >>> more_boar(64, 67)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(5, 79)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(72, 22)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(21, 19)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(72, 50)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(1, 82)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(980, 618)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(72, 89)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(21, 72)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(54, 56)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(28, 89)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(32, 45)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(208, 980)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(66, 46)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(41, 67)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(5, 0)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(14, 37)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(1, 17)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(69, 62)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(22, 34)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(404, 843)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(4, 48)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(45, 88)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(15, 36)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(87, 17)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(15, 61)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(53, 89)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(31, 56)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(12, 64)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(24, 85)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(2, 53)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(98, 23)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(10, 84)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(66, 18)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(11, 78)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(64, 76)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(1, 22)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(35, 67)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(752, 862)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(12, 44)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(37, 56)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(98, 80)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(14, 71)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(49, 21)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(84, 3)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(32, 95)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(31, 55)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(23, 59)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(68, 91)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(54, 12)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(70, 22)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(96, 73)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(32, 69)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(18, 89)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(6, 68)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(61, 77)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(14, 87)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(22, 79)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(1, 18)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(23, 79)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(40, 54)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(16, 47)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(9, 11)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(87, 82)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(38, 54)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(93, 6)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(21, 51)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(31, 55)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(139, 443)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(90, 55)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(24, 60)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(40, 81)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(79, 26)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(10, 16)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(73, 62)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(81, 8)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(0, 26)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(35, 59)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(40, 54)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(1, 23)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(50, 92)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(12, 44)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(31, 98)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(39, 0)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(97, 74)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(708, 563)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(796, 99)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(96, 61)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(49, 20)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(22, 43)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(31, 67)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(36, 2)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(18, 907)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(24, 79)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(3, 79)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(62, 5)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(97, 97)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(51, 53)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(63, 91)
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> more_boar(40, 73)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': r"""
      >>> from hog import *
      """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
